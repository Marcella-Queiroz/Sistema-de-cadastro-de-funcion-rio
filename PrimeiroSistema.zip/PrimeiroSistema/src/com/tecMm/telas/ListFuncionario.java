/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.tecMm.telas;

import com.tecMm.Outros.Formularios;
import com.tecMm.Outros.Temp;
import com.tecMm.bd.BancoDeDados;
import com.tecMm.funcionarios.Funcionario;
import java.util.ArrayList;
import javax.swing.JFrame;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author marcella.1963
 */
public class ListFuncionario extends javax.swing.JFrame {

    public ListFuncionario() {
        initComponents(); // Ativa as funçoes dos botões definidas na classe initComponents();
        
        setLocationRelativeTo(null); // Centraliza a janela.
        
        listar(BancoDeDados.listaFuncionario); // Chama a classe listar
    }
    
        public void listar(ArrayList<Funcionario> lista){
            DefaultTableModel defaultTableModel = (DefaultTableModel) tableFuncionario.getModel();
            defaultTableModel.setRowCount(0);
        
        for(Funcionario f : lista){
            defaultTableModel.addRow(new Object[]{f.getId(),f.getNome(),f.getDataNascimento(),f.getCpf(),f.getDataAdmissao()});
        }
    }// Mostra a lista com os funcionarios cadastrados
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jComboBox2 = new javax.swing.JComboBox<>();
        jPanel1 = new javax.swing.JPanel();
        CbFiltro = new javax.swing.JComboBox<>();
        tfFiltro = new javax.swing.JTextField();
        btFiltrar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tableFuncionario = new javax.swing.JTable();

        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        CbFiltro.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "ID", "NOME", "DATA NASCIMENTO", "CPF", "ADMISSÃO" }));
        CbFiltro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CbFiltroActionPerformed(evt);
            }
        });

        btFiltrar.setText("Filtrar");

        tableFuncionario.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "ID", "NOME", "DATA NASCIMENTO", "CPF", "DATA ADMISSÃO"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tableFuncionario.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tableFuncionarioMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tableFuncionario);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 627, Short.MAX_VALUE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(CbFiltro, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(tfFiltro)
                        .addGap(18, 18, 18)
                        .addComponent(btFiltrar)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(CbFiltro, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tfFiltro, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btFiltrar))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 321, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void CbFiltroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CbFiltroActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_CbFiltroActionPerformed

    //Permique que o usuario altere o cadastro quando a linha do funcionario cadastrado é clicado duas vezes na tela de listagem
    private void tableFuncionarioMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tableFuncionarioMouseClicked
        if(evt.getClickCount() == 2){
            Funcionario funcionario = new Funcionario();
            
            funcionario.setId(Integer.parseInt(String.valueOf(tableFuncionario.getValueAt(tableFuncionario.getSelectedRow(), 0))));
        
            funcionario.setNome(String.valueOf(tableFuncionario.getValueAt(tableFuncionario.getSelectedRow(),1)));
            
            funcionario.setDataNascimento(String.valueOf((String.valueOf(tableFuncionario.getValueAt(tableFuncionario.getSelectedRow(), 2)))));
        
            funcionario.setCpf(String.valueOf((String.valueOf(tableFuncionario.getValueAt(tableFuncionario.getSelectedRow(), 3)))));
            
            funcionario.setDataAdmissao(String.valueOf((String.valueOf(tableFuncionario.getValueAt(tableFuncionario.getSelectedRow(), 4)))));
            
            Temp.tempFunc = funcionario;
            
            if(Formularios.cadFuncionario == null)
                Formularios.cadFuncionario = new cadFuncionario();
            
            ((cadFuncionario) Formularios.cadFuncionario).verificarDadosTemporarios();
            Formularios.cadFuncionario.setVisible(true);
            Formularios.cadFuncionario.setExtendedState(JFrame.NORMAL);
        }
    }//GEN-LAST:event_tableFuncionarioMouseClicked

    //cria uma instância da classe ListFuncionario e a torna visível.         
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ListFuncionario().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> CbFiltro;
    private javax.swing.JButton btFiltrar;
    private javax.swing.JComboBox<String> jComboBox2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tableFuncionario;
    private javax.swing.JTextField tfFiltro;
    // End of variables declaration//GEN-END:variables
}
