/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.tecMm.telas;
import com.tecMm.Outros.Formularios;
import com.tecMm.Outros.Temp;
import com.tecMm.bd.BancoDeDados;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import com.tecMm.funcionarios.Funcionario;

public class cadFuncionario extends javax.swing.JFrame {

    public cadFuncionario() {
        initComponents(); // Ativa as funçoes dos botões definidas na classe initComponents();
        
        tfId.setEnabled(false); //Desabilita a edição do ID.
        
        proximoId();//Cria a sequencia do ID.
        
        setLocationRelativeTo(null); // Centraliza a janela.
        
        verificarDadosTemporarios(); // Chama a classe verificarDadosTemporarios().
    }
    
    public void verificarDadosTemporarios(){//Devolve os dados temporarios cadastrados na lista de edição de cadastro
        if(Temp.tempFunc!= null){
            Funcionario f = (Funcionario) Temp.tempFunc;
            
            tfId.setText(String.valueOf(f.getId()));
            tfNome.setText(f.getNome());
            tfDn.setText(f.getDataNascimento());
            tfCpf.setText(f.getCpf());
            tfDa.setText(f.getDataAdmissao());
            
            buttonSalvar.setText("Alterar");
            buttonExcluir.setVisible(true);
            buttonFechar.setVisible(true);
            setTitle("Alteracao de Produto");
        
        }else{
            buttonSalvar.setText("Salvar");
            buttonExcluir.setVisible(false);
            buttonFechar .setVisible(false);
            setTitle("Cadastro de Produto");
            
            tfNome.setText("");
            tfDn.setText("");
            tfCpf.setText("");
            tfDa.setText("");
        }    
    }//verificarDadosTemporarios.

    private void proximoId(){
        try{
            tfId.setText(String.valueOf(BancoDeDados.listaFuncionario.get(BancoDeDados.listaFuncionario.size() - 1).getId() + 1));
        }catch(IndexOutOfBoundsException e){
            tfId.setText("0");
        }
    } //gera uma sequencia de id a cada cadastro realizado.
    
     private void cadastrar(String Nome, String DataNascimento, String Cpf, String DataAdmissao, ArrayList<Funcionario> lista){
        int id;
            
        try{
            id = lista.get(lista.size() - 1).getId() + 1;
        }catch(IndexOutOfBoundsException e){
            id = 0;
        }
            
        lista.add(new Funcionario(id,Nome,DataNascimento,Cpf,DataAdmissao));
        JOptionPane.showMessageDialog(null, "Funcionário adicionado com sucesso!");
        tfNome.setText("");
        tfDn.setText("");
        tfCpf.setText("");
        tfDa.setText("");
        proximoId();
    } //Cadastrar funcionario.
     
    private void alterar(Funcionario f, String Nome, String DataNascimento, String Cpf, String DataAdmissao, ArrayList<Funcionario> lista){
        Funcionario funcAlt = new Funcionario(f.getId(),Nome,DataNascimento,Cpf,DataAdmissao); 

        lista.set(f.getId(),funcAlt);
        JOptionPane.showMessageDialog(null,"Produto alterado com sucesso.");
        tfNome.setText("");
        tfDn.setText("");
        tfCpf.setText("");
        tfDa.setText("");         
    } //Altera o cadastro do funcionario.
     
    private void deletar(Funcionario f, ArrayList<Funcionario> lista){
        lista.remove(f);
        JOptionPane.showMessageDialog(null,"Produto removido com sucesso");
        tfNome.setText("");
        tfDn.setText("");
        tfCpf.setText("");
        tfDa.setText("");
    } //Deleta o funcionario cadastrado.
   
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        buttonSalvar = new javax.swing.JButton();
        labelCPF = new javax.swing.JLabel();
        tfNome = new javax.swing.JTextField();
        labelNome = new javax.swing.JLabel();
        tfDn = new javax.swing.JTextField();
        labelDn = new javax.swing.JLabel();
        tfCpf = new javax.swing.JTextField();
        labelDa = new javax.swing.JLabel();
        tfDa = new javax.swing.JTextField();
        labelId = new javax.swing.JLabel();
        tfId = new javax.swing.JTextField();
        buttonFechar = new javax.swing.JButton();
        buttonExcluir = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        textCdFunc = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        buttonSalvar.setText("Salvar");
        buttonSalvar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonSalvarActionPerformed(evt);
            }
        });

        labelCPF.setText("CPF:");

        tfNome.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tfNomeActionPerformed(evt);
            }
        });

        labelNome.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        labelNome.setText("Nome:");

        labelDn.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        labelDn.setText("Data de Nascimento:");

        labelDa.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        labelDa.setText("Data de Admissão:");

        labelId.setText("ID:");

        buttonFechar.setText("Fechar");
        buttonFechar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonFecharActionPerformed(evt);
            }
        });

        buttonExcluir.setText("Excluir");
        buttonExcluir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonExcluirActionPerformed(evt);
            }
        });

        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imgs/Funcionario.png"))); // NOI18N
        jLabel1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        textCdFunc.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 14)); // NOI18N
        textCdFunc.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        textCdFunc.setText("Cadastro de Funcionários");
        textCdFunc.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        textCdFunc.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jLabel1)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(6, 6, 6)
                                .addComponent(labelId, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(tfId)))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(tfNome, javax.swing.GroupLayout.PREFERRED_SIZE, 178, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(labelNome)
                            .addComponent(tfDn, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(labelDn))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 134, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(labelCPF)
                            .addComponent(labelDa)
                            .addComponent(tfDa, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tfCpf, javax.swing.GroupLayout.PREFERRED_SIZE, 138, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(buttonSalvar)
                        .addGap(18, 18, 18)
                        .addComponent(buttonExcluir)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(buttonFechar)))
                .addGap(48, 48, 48))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(textCdFunc, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addComponent(textCdFunc, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(tfId, javax.swing.GroupLayout.DEFAULT_SIZE, 26, Short.MAX_VALUE)
                    .addComponent(labelId))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(labelNome)
                            .addComponent(labelCPF))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(tfNome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tfCpf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(33, 33, 33)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(labelDn)
                            .addComponent(labelDa))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(tfDn, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tfDa, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jLabel1))
                .addGap(84, 84, 84)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(buttonSalvar)
                    .addComponent(buttonExcluir)
                    .addComponent(buttonFechar))
                .addGap(40, 40, 40))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /* Questiona ousuario sobre a exclusão do funcionario, se a resposta for "sim",é chamado o metodo deletar e remove o funcionario do bando de dados
    em seguida verifica se o formulario de listagem não é nulo,e, se não for,mostra a lista atualizada, e por fim, limpa os dados temporarios do formulario*/
    private void buttonExcluirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonExcluirActionPerformed
        if(JOptionPane.showConfirmDialog(null, "Deseja realmente excluir este Funcionario?")==JOptionPane.YES_OPTION){
            deletar((Funcionario)Temp.tempFunc ,BancoDeDados.listaFuncionario);

            if(Formularios.listFuncionario != null)
            ((ListFuncionario) Formularios.listFuncionario).listar(BancoDeDados.listaFuncionario);

            Temp.limpar();
            verificarDadosTemporarios();
            proximoId();
        }
    }//GEN-LAST:event_buttonExcluirActionPerformed

    // É chamado quando o botão “Fechar” é clicado .Ele limpa os dados temporários (Temp.limpar()) e verifica os dados temporários.
    private void buttonFecharActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonFecharActionPerformed
        //        Formularios.listFuncionario = null;;
        Temp.limpar();

        verificarDadosTemporarios();
    }//GEN-LAST:event_buttonFecharActionPerformed

    private void tfNomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tfNomeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tfNomeActionPerformed

    // É chamado quando o botão “Salvar” é clicado.
    private void buttonSalvarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonSalvarActionPerformed
        if(Temp.tempFunc == null){
            cadastrar(tfNome.getText(),tfDn.getText(),tfCpf.getText(),tfDa.getText(), BancoDeDados.listaFuncionario);

            if(Formularios.listFuncionario != null)
            ((ListFuncionario) Formularios.listFuncionario).listar(BancoDeDados.listaFuncionario);

            Temp.limpar();

            verificarDadosTemporarios();
        }else{
            alterar((Funcionario) Temp.tempFunc, tfNome.getText(), tfDn.getText(),tfCpf.getText(),tfDa.getText(),BancoDeDados.listaFuncionario);

            if(Formularios.listFuncionario != null)
            ((ListFuncionario) Formularios.listFuncionario).listar(BancoDeDados.listaFuncionario);

            Temp.limpar();

            verificarDadosTemporarios();

            proximoId();
        }
    }//GEN-LAST:event_buttonSalvarActionPerformed


    
    
    //cria uma instância da classe cadFuncionario e a torna visível.  
    public static void main(String args[]) {
      
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new cadFuncionario().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton buttonExcluir;
    private javax.swing.JButton buttonFechar;
    private javax.swing.JButton buttonSalvar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel labelCPF;
    private javax.swing.JLabel labelDa;
    private javax.swing.JLabel labelDn;
    private javax.swing.JLabel labelId;
    private javax.swing.JLabel labelNome;
    private javax.swing.JLabel textCdFunc;
    private javax.swing.JTextField tfCpf;
    private javax.swing.JTextField tfDa;
    private javax.swing.JTextField tfDn;
    private javax.swing.JTextField tfId;
    private javax.swing.JTextField tfNome;
    // End of variables declaration//GEN-END:variables
}
