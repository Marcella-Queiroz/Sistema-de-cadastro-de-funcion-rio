package com.tecMm.telas;

import com.tecMm.Outros.Formularios;
import com.tecMm.telas.cadFuncionario;
import com.tecMm.telas.ListFuncionario;
import javax.swing.JFrame;

public class MenuPrincipal extends javax.swing.JFrame {

    public MenuPrincipal() {
        initComponents();// Ativa as funçoes dos botões definidas na classe initComponents();
        
        setLocationRelativeTo(null); // Centraliza a janela.
        
        //setExtendedState(MAXIMIZED_BOTH); //Deixa a pagina Maximizada.
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jFileChooser1 = new javax.swing.JFileChooser();
        painelMenuPrincipal = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        mbOpcao = new javax.swing.JMenuBar();
        menuOpcao = new javax.swing.JMenu();
        mICadastro = new javax.swing.JMenuItem();
        mIListagem = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imgs/Logo_TecMM.png"))); // NOI18N

        javax.swing.GroupLayout painelMenuPrincipalLayout = new javax.swing.GroupLayout(painelMenuPrincipal);
        painelMenuPrincipal.setLayout(painelMenuPrincipalLayout);
        painelMenuPrincipalLayout.setHorizontalGroup(
            painelMenuPrincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, painelMenuPrincipalLayout.createSequentialGroup()
                .addContainerGap(194, Short.MAX_VALUE)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 265, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(180, 180, 180))
        );
        painelMenuPrincipalLayout.setVerticalGroup(
            painelMenuPrincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(painelMenuPrincipalLayout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 278, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(54, Short.MAX_VALUE))
        );

        menuOpcao.setText("Opções");

        mICadastro.setText("Cadastro de Funcionário");
        mICadastro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mICadastroActionPerformed(evt);
            }
        });
        menuOpcao.add(mICadastro);

        mIListagem.setText("Listagem");
        mIListagem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mIListagemActionPerformed(evt);
            }
        });
        menuOpcao.add(mIListagem);

        mbOpcao.add(menuOpcao);

        setJMenuBar(mbOpcao);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(painelMenuPrincipal, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(painelMenuPrincipal, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    //Abre a tela de Listagem.
    private void mIListagemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mIListagemActionPerformed
        if(Formularios.listFuncionario == null)
            Formularios.listFuncionario = new ListFuncionario();
            Formularios.listFuncionario.setVisible(true);
            Formularios.listFuncionario.setExtendedState(JFrame.NORMAL);
        
    }//GEN-LAST:event_mIListagemActionPerformed

    //Abre a tela de cadastro.
    private void mICadastroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mICadastroActionPerformed
         if(Formularios.cadFuncionario == null)
            Formularios.cadFuncionario = new cadFuncionario();
            Formularios.cadFuncionario.setVisible(true);
            Formularios.cadFuncionario.setExtendedState(JFrame.NORMAL);
    }//GEN-LAST:event_mICadastroActionPerformed

    // Configuração do Look and Feel (aparência visual).
    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MenuPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(MenuPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(MenuPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MenuPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MenuPrincipal().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JFileChooser jFileChooser1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JMenuItem mICadastro;
    private javax.swing.JMenuItem mIListagem;
    private javax.swing.JMenuBar mbOpcao;
    private javax.swing.JMenu menuOpcao;
    private javax.swing.JPanel painelMenuPrincipal;
    // End of variables declaration//GEN-END:variables
}
