package com.tecMm.bd;

import com.tecMm.funcionarios.Funcionario;
import java.util.ArrayList;

public class BancoDeDados {
     public static ArrayList<Funcionario> listaFuncionario = new ArrayList<>();
}
