package com.tecMm.Outros;

public class Temp {
    public static Object tempFunc;
    
    public static void limpar(){
        tempFunc = null;
    }
}
