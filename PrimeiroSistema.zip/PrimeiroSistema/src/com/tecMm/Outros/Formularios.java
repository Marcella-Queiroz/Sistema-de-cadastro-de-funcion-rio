package com.tecMm.Outros;

import javax.swing.JFrame;

public class Formularios {
    public static JFrame cadFuncionario;
    public static JFrame listFuncionario;
}
